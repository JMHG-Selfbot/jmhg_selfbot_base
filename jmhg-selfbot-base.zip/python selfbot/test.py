test = "="
test2 = "=" * 6
print(test2)